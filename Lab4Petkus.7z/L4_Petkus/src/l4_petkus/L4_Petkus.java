/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package l4_petkus;

/**
 *
 * @author Tautvydas
 */
public class L4_Petkus {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new KiaulėLangas();
    }
}
