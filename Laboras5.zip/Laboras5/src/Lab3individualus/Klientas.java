/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab3individualus;

import Laboras3demo.Automobilis;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;
import studijosKTU.DataKTU;
import studijosKTU.Ks;

/**
 *
 * @author Karolis Ryselis
 */
public class Klientas implements DataKTU {

    public static int getMin_amzius() {
        return min_amzius;
    }

    public static void setMin_amzius(int min_amzius) {
        Klientas.min_amzius = min_amzius;
    }

    public static int getMax_amzius() {
        return max_amzius;
    }

    public static void setMax_amzius(int max_amzius) {
        Klientas.max_amzius = max_amzius;
    }

    public static int getMin_kodo_ilgis() {
        return min_kodo_ilgis;
    }

    public static void setMin_kodo_ilgis(int min_kodo_ilgis) {
        Klientas.min_kodo_ilgis = min_kodo_ilgis;
    }

    public static int getMax_kodo_ilgis() {
        return max_kodo_ilgis;
    }

    public static void setMax_kodo_ilgis(int max_kodo_ilgis) {
        Klientas.max_kodo_ilgis = max_kodo_ilgis;
    }

    public String getPavadinimas() {
        return pavadinimas;
    }

    public void setPavadinimas(String pavadinimas) {
        this.pavadinimas = pavadinimas;
    }

    public String getKodas() {
        return kodas;
    }

    public void setKodas(String kodas) {
        this.kodas = kodas;
    }

    public Automobilis getAutomobilis() {
        return automobilis;
    }

    public void setAutomobilis(Automobilis automobilis) {
        this.automobilis = automobilis;
    }

    public int getAmzius() {
        return amzius;
    }

    public void setAmzius(int amzius) {
        this.amzius = amzius;
    }
    static int min_amzius = 18;
    static int max_amzius = 80;
    static int min_kodo_ilgis = 2;
    static int max_kodo_ilgis = 10;
    
    String pavadinimas;
    String kodas;
    Automobilis automobilis;
    int amzius;
    
    Klientas(){};
    
    Klientas(String pav, String kod, Automobilis aut, int amz){
        this.pavadinimas = pav;
        this.kodas = kod;
        this.automobilis = aut;
        this.amzius = amz;
    }
    
    Klientas(String dataString){
        this.fromString(dataString);
    }

    public DataKTU create(String dataString) {
        return new Klientas(dataString);
    }

    public String validate() {
        String klaidos = "";
        if (this.amzius > this.max_amzius){
            klaidos += "Įvestas amžius per didelis, didžiausia galima reikšmė " + Integer.toString(this.amzius);
        }
        if (this.amzius < this.min_amzius){
            klaidos += "Įvestas amžius per mažas, mažiausia galima reikšmė " + Integer.toString(this.amzius);
        }
        return klaidos;
    }

    public void fromString(String e) {
        try{
            Scanner scan = new Scanner(e);
            pavadinimas = scan.next();
            kodas = scan.next();
            amzius = scan.nextInt();
            String marke = scan.next();
            String modelis = scan.next();
            int gammetai = scan.nextInt();
            int rida = scan.nextInt();
            double kaina = scan.nextDouble();
            validate();
            automobilis = new Automobilis(marke, modelis, gammetai, rida, kaina);
            automobilis.validate();
        }
        catch (InputMismatchException exc){
            Ks.ern("Neteisingi duomenys");
        }
        catch (NoSuchElementException exc){
            Ks.ern("Ivesti ne visi duomenys");
        }
    }
    
    
    
    @Override
    public String toString(){
        return String.format("%-20s %7s %4d %50s" ,this.pavadinimas, this.kodas, 
                this.amzius, this.automobilis.toString());
    }
    
    public int compareTo(Object o) {
        int res = this.pavadinimas.compareTo(((Klientas)o).pavadinimas);
        if (res == 0){
            res = this.kodas.compareTo(((Klientas)o).kodas);
        }
        return res;
    }
    
    public static Comparator<Klientas> pagalAmziu = new Comparator<Klientas>(){
        public int compare (Klientas k1, Klientas k2){
            if (k1.getAmzius() > k2.getAmzius()){
                return 1;
            }
            if (k2.getAmzius() > k1.getAmzius()){
                return -1;
            }
            return 0;
        }
    };
    
    public static Comparator<Klientas> pagalKoda = new Comparator<Klientas>(){
        public int compare (Klientas k1, Klientas k2){
            return k1.pavadinimas.compareTo(k2.pavadinimas);
        }
    };
    
    public static Comparator<Klientas> pagalAutomobilioKaina = new Comparator<Klientas>(){
        public int compare (Klientas k1, Klientas k2){
            if (k1.automobilis.getKaina() > k2.automobilis.getKaina()){
                return 1;
            }
            if (k2.automobilis.getKaina() > k1.automobilis.getKaina()){
                return -1;
            }
            return 0;
        }
    };
    
    public static Comparator<Klientas> pagalAutomobilioMetus = new Comparator<Klientas>(){
        public int compare(Klientas k1, Klientas k2){
            if (k1.automobilis.getGamMetai() > k2.automobilis.getGamMetai()){
                return 1;
            }
            if (k2.automobilis.getGamMetai() > k1.automobilis.getGamMetai()){
                return -1;
            }
            return 0;
        }
    };
    
    public static Comparator<Klientas> pagalPavadinima = new Comparator<Klientas>(){
        public int compare(Klientas k1, Klientas k2){
            return k1.pavadinimas.compareTo(k2.pavadinimas);
        }
    };
    
}
