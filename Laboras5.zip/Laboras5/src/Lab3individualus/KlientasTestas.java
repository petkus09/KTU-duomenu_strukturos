/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab3individualus;

import Laboras3demo.Automobilis;
import java.util.Comparator;
import studijosKTU.Ks;
import studijosKTU.ListKTUx;

/**
 *
 * @author Karolis Ryselis
 */
public class KlientasTestas {
    static ListKTUx <Klientas> sarasas = new ListKTUx <Klientas> (new Klientas());
    
    public void tikrintiKlientus(){
        Klientas k1 = new Klientas("Autotestas", "123456", 
                new Automobilis("Lamborghini", "Murcielago", 2010, 10000, 
                1000000), 30);
        Klientas k2 = new Klientas("Autotestas 123456 30 Lamborghini Murcielago 2010 10000 1000000");
        Ks.oun("Palyginimas");
        Ks.ouf("%d %d\n",k1.amzius, k2.amzius);
        Ks.ouf("%s    %s\n", k1.automobilis,k2.automobilis);
        Ks.ouf("%s %s\n",k1.kodas,k2.kodas);
        Ks.ouf("%s %s\n",k1.pavadinimas,k2.pavadinimas);
    }
    
    public void FormuotiSarasa(){
        sarasas.add(new Klientas("Autotestas", "123456", 
                new Automobilis("Lamborghini", "Murcielago", 2010, 10000, 
                1000000), 30));
        sarasas.add(new Klientas("Mototestas", "234567",
                new Automobilis("Volkswagen", "Golf", 1995, 140000, 5000), 35));
        sarasas.add(new Klientas("Vežimotestas", "345678",
                new Automobilis("Ford", "Ka", 2000, 70000, 10000), 40));
        sarasas.add(new Klientas("Visainetestas", "456789",
                new Automobilis("Opel", "Corsa", 1992, 200000, 3000), 45));
        sarasas.println("Sąraše yra:");
        Ks.oun("Triname seniausią");
        /*int metai = 2013;
        int indeksas = 0;
        int i = 0;
        for (Klientas k = sarasas.get(0); k != null; k = sarasas.getNext()){
            if (metai > k.automobilis.getGamMetai()){
                metai = k.automobilis.getGamMetai();
                indeksas = i;
            }
            i++;
        }
        sarasas.remove(indeksas);
        sarasas.println("Sąraše liko");*/
        sarasas.save("myfile.txt");
    }
    
    public void apskaitosTestas(){
        ListKTUx<Klientas> sarasas = new ListKTUx<Klientas>(new Klientas());
        sarasas.load("myfile.txt");
        KlientoApskaita aps = new KlientoApskaita();
        aps.visiKlientai = sarasas;
        aps.visiKlientai.println("Visi klientai");
        ListKTUx<Klientas> sarasasPagalModeli = aps.atrinktiMarkęModelį("Volkswagen");
        sarasasPagalModeli.println("Visi klientai su Volkswagenais");
        ListKTUx<Klientas> sarasasPagalKaina = aps.atrinktiPagalKainą(10000, 30000);
        sarasasPagalKaina.println("Klientai su automobiliais tarp 10000 ir 30000 pinigų");
        ListKTUx<Klientas> sarasasPagalMetus = aps.atrinktiNaujusKlientas(2000);
        sarasasPagalMetus.println("Klientai su naujomis mašinomis");
        ListKTUx<Klientas> sarasasBrangiausias = aps.maksimaliosKainosKlientas();
        sarasasBrangiausias.println("Klientas su brangiausia mašina");
    }
    
    public void rikiavimoTestas(){
        ListKTUx<Klientas> sarasas = new ListKTUx<Klientas>(new Klientas());
        sarasas.load("myfile.txt");
        sarasas.println("Pradinis sąrašas");
        sarasas.sort(Klientas.pagalAmziu);
        sarasas.println("Surikiuota pagal amžių");
        sarasas.sort(Klientas.pagalAutomobilioKaina);
        sarasas.println("Surikiuota pagal automobilio kainą");
        sarasas.sort(Klientas.pagalAutomobilioMetus);
        sarasas.println("Surikiuota pagal automobilio metus");
        sarasas.sort(Klientas.pagalKoda);
        sarasas.println("Surikiuota pagal kodą");
    }
}
