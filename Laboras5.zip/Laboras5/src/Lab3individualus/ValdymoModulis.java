package Lab3individualus;
import Laboras3demo.AutoApskaita;
import Laboras3demo.Automobilis;
import java.util.Locale;
import studijosKTU.*;

/*
 * Darbo Atlikimo tvarka:
 * 1 - Išnagrinėti klasės Ks metodus, panaudojant klasę DemoKTUsystem
 * 2 - Išnagrinėti klasės Automobilis struktūrą
 */

public class ValdymoModulis {
    static AutoApskaita ap = new AutoApskaita();

   public static void main(String[] args) {
      Locale.setDefault(Locale.US); // suvienodiname skaičių formatus

//      DemoKTUsystem.metodoParinkimas();
//      AutomobiliuTestai.metodoParinkimas();
//      bendravimasSuKlientu();
      KlientasTestas kt = new KlientasTestas();
      
      //kt.tikrintiKlientus();
      //kt.FormuotiSarasa();
      //kt.apskaitosTestas();
      //kt.rikiavimoTestas();
      //bendravimas(null);
      GreitaveikosTyrimas gt = new GreitaveikosTyrimas();
      gt.tyrimas();
   }

   public static void bendravimasSuKlientu() {
      ListKTUx<Automobilis> atranka = 
              new ListKTUx<Automobilis>(new Automobilis());
      int varNr;  // skaičiavimo varijantas pasirenkamas nurodant jo numerį
      String dialogas = "Pasirinkimas: "
            + "1-skaityti iš failo; 2-papildyti sąrašą; "
            + "3-naujų atranka;\n    4-atranka pagal kainą; "
            + "5-brangiausi auto; 6-pagal markę; 0-baigti skaičiavimus > ";
      while ((varNr = Ks.giveInt(dialogas,0,6)) != 0) {
         if (varNr == 1) {
            ap.visiAuto.load(Ks.giveFileName());
            ap.visiAuto.println("Visų automobilių sąrašas");
         } else {
            if (varNr == 2) {
               String autoD = Ks.giveString("Nurodykite auto markę, "+
                            "modelį, gamybos metus, ridą ir kainą\n ");
               Automobilis a=new Automobilis(autoD);
               String klaidosPožymis=a.validate();
               if (klaidosPožymis.length()==0)
                   ap.visiAuto.add(a);
               else
                 Ks.oun("Automobilis į sąrašą nepriimtas "+klaidosPožymis);
            } else {  // toliau vykdomos atskiri atrankos metodai
               switch (varNr) {
                  case 3:
                     int nR = Ks.giveInt("Nurodykite naujų auto metų ribą: ");
                     atranka = ap.atrinktiNaujusAuto(nR);
                     break;
                  case 4:
                     int r1 = Ks.giveInt("Nurodykite apatinę kainos ribą: ");
                     int r2 = Ks.giveInt("Nurodykite viršutinę kainos ribą: ");
                     atranka = ap.atrinktiPagalKainą(r1, r2);
                     break;
                  case 5:
                     atranka = ap.maksimaliosKainosAuto();
                     break;
                  case 6:
                     String markė=Ks.giveString("Nurodykite norimą markę ir"+
                             " modelį, atskirtus tarpu: ");
                     atranka = ap.atrinktiMarkęModelį(markė);
                     break;
               }
               atranka.println("Štai atrinktų automobilių sąrašas");
               atranka.save(Ks.giveString
                     ("Kur saugoti atrinktus auto (jei ne-tai ENTER) ? "));
            }
         }
      }
   }
   
  /* public static void bendravimas(ListKTUx<Klientas> klientai){
       if (klientai == null){
           klientai = new ListKTUx<Klientas>(new Klientas());
       }
       int pasirinkimas = Ks.giveInt("Pasirinkimai: 1- įvesti klientus, 2- spausdinti klientų sąrašą, 3- išsaugoti sąrašą faile\n"
               + "4- rasti klientus su naujais automobiliais, 5- rasti klientus pagal automobilio kainą\n"
               + "6- rasti klientus pagal automobilio markę/modelį, 7- rasti klientą brangiausiu automobiliu\n"
               + "8- rasti klientą pagal amžių, 9- įkelti klientus iš failo, 10- įvesti kelis klientus\n"
               + "11- rasti bendrus klientus\n"
               + " 0- baigti", 0, 11);
       switch (pasirinkimas){
           case 0:
               return;
           case 1:
               String duomenys = Ks.giveString("Įveskite kliento duomenis: pavadinimas, kodas, amžius, automobilio markė, modelis, gamybos metai, rida, kaina\n");
               klientai.add(new Klientas(duomenys));
               if (klientai.size() != 0){
                   klientai.println("Turimi klientai");
                   bendravimas(klientai);
               }
               break;
           case 2:
               klientai.println("Klientų sąrašas");
               bendravimas(klientai);
               break;
           case 3:
               String filename = Ks.giveString("Įveskite failo pavadinimą");
               klientai.save(filename);
               Ks.oun("Išspausdinta");
               bendravimas(klientai);
               break;
           case 4:
               KlientoApskaita ka = new KlientoApskaita();
               ka.visiKlientai = klientai;
               int riba = Ks.giveInt("Įveskite gamybos metus");
               ListKTUx naujiKlientai = ka.atrinktiNaujusKlientas(riba);
               naujiKlientai.println("Klientai su naujais automobiliais");
               int atsakymas = Ks.giveInt("Ar norite pakeisti senus duomenis? (0/1)", 0, 1);
               if (atsakymas == 1){
                   klientai = naujiKlientai;
               }
               bendravimas(klientai);
               break;
           case 5:
               KlientoApskaita kb = new KlientoApskaita();
               kb.visiKlientai = klientai;
               int minriba = Ks.giveInt("Įveskite mažiausią kainą");
               int maxriba = Ks.giveInt("Įveskite didžiausią kainą");
               ListKTUx kaina = kb.atrinktiPagalKainą(minriba, maxriba);
               kaina.println("Klientai su automobiliais, kurių kaina nuo " + Integer.toString(minriba)
                       + " iki " + Integer.toString(maxriba));
               int atsakymas5 = Ks.giveInt("Ar norite pakeisti senus duomenis? (0/1)", 0, 1);
               if (atsakymas5 == 1){
                   klientai = kaina;
               }
               bendravimas(klientai);
               break;
           case 6:
               KlientoApskaita kc = new KlientoApskaita();
               kc.visiKlientai = klientai;
               String marke = Ks.giveString("Įveskite automobilio markę ar modelį");
               ListKTUx markesModeliai = kc.atrinktiMarkęModelį(marke);
               markesModeliai.println("Klientai su automobiliais " + marke);
               int atsakymas6 = Ks.giveInt("Ar norite pakeisti senus duomenis? (0/1)", 0, 1);
               if (atsakymas6 == 1){
                   klientai = markesModeliai;
               }
               bendravimas(klientai);
               break;
           case 7:
               KlientoApskaita kd = new KlientoApskaita();
               kd.visiKlientai = klientai;
               ListKTUx maxklientas = kd.maksimaliosKainosKlientas();
               maxklientas.println("Klientas su brangiausiu automobiliu");
               int atsakymas7 = Ks.giveInt("Ar norite pakeisti senus duomenis? (0/1)", 0, 1);
               if (atsakymas7 == 1){
                   klientai = maxklientas;
               }
               bendravimas(klientai);
               break;
           case 8:
               KlientoApskaita ke = new KlientoApskaita();
               ke.visiKlientai = klientai;
               int minamzius = Ks.giveInt("Įveskite minimalų kliento amžių", Klientas.min_amzius, Klientas.max_amzius);
               int maxamzius = Ks.giveInt("Įveskite maksimalų kliento amžių", Klientas.min_amzius, Klientas.max_amzius);
               ListKTUx amzius = ke.atrinktiPagalAmziu(minamzius, maxamzius);
               amzius.println("Klientai, kurių amžius nuo " + Integer.toString(minamzius) + " iki " 
                       + Integer.toString(maxamzius));
               int atsakymas8 = Ks.giveInt("Ar norite pakeisti senus duomenis? (0/1)", 0, 1);
               if (atsakymas8 == 1){
                   klientai = amzius;
               }
               ke.atrinktiPagalAmziu(minamzius, maxamzius);
               bendravimas(klientai);
               break;
           case 9:
               String fn = Ks.giveString("Įveskite failo vardą");
               klientai.load(fn);
               bendravimas(klientai);
               break;
           case 10:
               String klientas = "";
               ListKTUx<Klientas> nauji = new ListKTUx<Klientas>(new Klientas());
               while (!klientas.equals("0")){
                   klientas = Ks.giveString("Įveskite kliento duomenis: pavadinimas, kodas, amžius, automobilio markė, modelis, gamybos metai, rida, kaina\nĮvedimui pabaigti įveskite 0\n");
                   if (!klientas.equals("0")){
                       nauji.add(new Klientas(klientas));
                   }
               }
               klientai.join(nauji);
               klientai.println("Turimi klientai");
               bendravimas(klientai);
               break;
           case 11:
               KlientoApskaita kf = new KlientoApskaita();
               kf.visiKlientai = klientai;
               int minamzius1 = Ks.giveInt("Įveskite minimalų kliento amžių", Klientas.min_amzius, Klientas.max_amzius);
               int maxamzius1 = Ks.giveInt("Įveskite maksimalų kliento amžių", Klientas.min_amzius, Klientas.max_amzius);
               ListKTUx amzius1 = kf.atrinktiPagalAmziu(minamzius1, maxamzius1);
               amzius1.println("Klientai, kurių amžius nuo " + Integer.toString(minamzius1) + " iki " 
                       + Integer.toString(maxamzius1));
               ListKTUx bendri = klientai.common_elements(amzius1);
               bendri.println("Bendri klientai");
               int atsakymas11 = Ks.giveInt("Ar norite pakeisti senus duomenis? (0/1)", 0, 1);
               if (atsakymas11 == 1){
                   klientai = amzius1;
               }
               kf.atrinktiPagalAmziu(minamzius1, maxamzius1);
               bendravimas(klientai);
               break;
       }
   }*/
}
