package Lab3individualus;
import studijosKTU.*;

public class KlientoApskaita {

   public ListKTUx<Klientas> visiKlientai = new ListKTUx(new Klientas());

   public ListKTUx<Klientas> atrinktiNaujusKlientas(int nRiba) {
      ListKTUx<Klientas> naujiKlientas = new ListKTUx(new Klientas());
      for (Klientas k: visiKlientai) {
         if (k.automobilis.getGamMetai() >= nRiba) {
            naujiKlientas.add(k);
         }
      }
      return naujiKlientas;
   }

   public ListKTUx<Klientas> atrinktiPagalKainą(int riba1, int riba2) {
      ListKTUx<Klientas> vidutiniaiKlientas = new ListKTUx(new Klientas());
      // normaliai organizuotos peržiūros pavyzdys
      for (Klientas k: visiKlientai) {
         if (k.automobilis.getKaina() >= riba1 && k.automobilis.getKaina() <= riba2) {
            vidutiniaiKlientas.add(k);
         }
      }
      return vidutiniaiKlientas;
   }

   public ListKTUx<Klientas> maksimaliosKainosKlientas() {
      ListKTUx<Klientas> brangiausiKlientas = new ListKTUx(new Klientas());
      // formuojamas sąrašas su maksimalia reikšme
      double maxKaina = 0;
      for (Klientas k : visiKlientai){
         double kaina=k.automobilis.getKaina();
         if (kaina >= maxKaina) {
            if (kaina > maxKaina) {
               brangiausiKlientas.clear();
               maxKaina = kaina;
            }
            brangiausiKlientas.add(k);
         }
      }
      return brangiausiKlientas;
   }

   public ListKTUx<Klientas> atrinktiMarkęModelį(String modelioKodas) {
      ListKTUx<Klientas> firminiaiKlientas = new ListKTUx(new Klientas());
      for (Klientas k : visiKlientai){
         String pilnasModelis=k.automobilis.getMarkė()+" "+k.automobilis.getModelis();
         if (pilnasModelis.startsWith(modelioKodas)) {
            firminiaiKlientas.add(k);
         }
      }
      return firminiaiKlientas;
   }
   
   public ListKTUx atrinktiPagalAmziu(int amzius_min, int amzius_max){
       ListKTUx klientaiPagalAmziu = new ListKTUx(new Klientas());
       for (Klientas k : visiKlientai){
           int amzius = k.getAmzius();
           if (amzius >= amzius_min && amzius <= amzius_max){
               klientaiPagalAmziu.add(k);
           }
       }
       return klientaiPagalAmziu;
   }
}
