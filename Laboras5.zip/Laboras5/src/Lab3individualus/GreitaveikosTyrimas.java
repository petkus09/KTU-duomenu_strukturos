/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab3individualus;

import Laboras3demo.Automobilis;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import studijosKTU.ArraysKTU;
import studijosKTU.Ks;
import studijosKTU.ListKTU;
import studijosKTU.Timekeeper;

/**
 *
 * @author Karolis Ryselis
 */
public class GreitaveikosTyrimas {
    public Random ag = new Random();
    public ListKTU<Klientas> generuoti_sarasa(int kiekis){
        String[][] am = { // galimų automobilių markių ir jų modelių masyvas
          {"Mazda", "121", "323", "626", "MX6"},
          {"Ford", "Fiesta", "Escort", "Focus", "Sierra", "Mondeo"},
          {"Saab", "92", "96"},
          {"Honda", "Accord", "Civic", "Jazz"},
          {"Renault", "Laguna", "Megane", "Twingo", "Scenic"},
          {"Peugeot", "206", "207", "307"}
       };
        Automobilis [] autoBazė1= new Automobilis[kiekis];
        ag.setSeed(1949);
        for(int i=0;i<kiekis;i++){
            int ma = ag.nextInt(am.length);        // markės indeksas  0..
            int mo = ag.nextInt(am[ma].length-1)+1;// modelio indeksas 1..
            autoBazė1[i]= new Automobilis(am[ma][0], am[ma][mo],
                1990+ag.nextInt(20),     // metai tarp 1990 ir 2009
                6000+ag.nextInt(222000), // rida tarp 6000 ir 228000
                800+ ag.nextDouble()*88000); // kaina tarp 800 ir 88800
        }
        Collections.shuffle(Arrays.asList(autoBazė1));
        Klientas [] klientoBaze1 = new Klientas[kiekis];
        for (int i = 0; i < kiekis; i++){
            String pavadinimas = autoBazė1[i].getMarkė() + " vairuotojas";
            String kodas = Integer.toString(100000+ag.nextInt(899999));
            int amzius = 18+ag.nextInt(62);
            klientoBaze1[i] = new Klientas(pavadinimas, kodas, autoBazė1[i], amzius);
        }
        Collections.shuffle(Arrays.asList(klientoBaze1));
        ListKTU<Klientas> res = new ListKTU<Klientas>();
        for (Klientas k : klientoBaze1){
            res.add(k);
        }
        return res;
    }
    public void tyrimas(){
        
        int kiekiai [] = {10,20,40,80,16,320,640,1280,2560,5120,10240,20480,40960,81920,
        163840,327680,655360};
        Timekeeper tk = new Timekeeper(kiekiai);
        for (int kiekis : kiekiai) {
           ListKTU<Klientas> klientai = generuoti_sarasa(kiekis);
           ListKTU<Klientas> klientai2=(ListKTU<Klientas>)klientai.clone();
           ListKTU<Klientas> klientai3=(ListKTU<Klientas>)klientai.clone();
           ListKTU<Klientas> klientai4=(ListKTU<Klientas>)klientai.clone();

//  Greitaveikos bandymai ir laiko matavimai
            tk.start();
            klientai.sort();
            tk.finish("SysBeCom");
            klientai2.sort(Klientas.pagalPavadinima);
            tk.finish("SysSuCom");
            klientai3.sortBurbuliuku();
            tk.finish("BurBeCom");
            klientai4.sortBurbuliuku(Klientas.pagalPavadinima);
            tk.finish("BurSuCom");
            tk.seriesFinish();
        }
        
    }
}
