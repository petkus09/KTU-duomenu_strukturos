package suMeniu;

/**
 *
 * @author  Aleksas
 */
import Lab3individualus.Klientas;
import Lab3individualus.KlientoApskaita;
import dialogai.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.io.*;
import javax.swing.table.DefaultTableModel;
import studijosKTU.ListKTUx;

/**
 * Sąsajos pavyzdys su meniu ir JTextArea elementu duomenu/rezultatų išvedimui
 *
 * !!!! Tai tik pavyzdys, todėl galima laisvai fantazuoti.
 * Panaudokite JTable elementų išvedimui, išplėskite meniu ir t.t
 *
 * @author Aleksas
 */

public class SasajaSuMeniu extends JFrame {

    private JMenuBar meniuBaras = new JMenuBar();
	private Container vidus;
    private JLabel laPiešinys = new JLabel("initial picture");
    private Dimension žymėsDydis;
    private JTextArea taInformacija = new JTextArea(20, 40);
    private JLabel laAntraste = new JLabel("Results");
    private JPanel paPiešinukas = new JPanel();
    private boolean rodytiPiešinuką = true;
    private JFrame kviečiantisObjektas = this;
    private JPanel pa1 = new JPanel();
    private ClientAccounting	apskaita = new ClientAccounting();
    private Object [] cols = {"Name", "Code", "Age",
                                "Car name", "Car model", "Run", "Mnf. year", "Price"};
    private Object [][] data = new Object[0][0];
    DefaultTableModel model = new DefaultTableModel(data, cols); 
    JTable table = new JTable(model); 
    
    private JScrollPane zona = new JScrollPane(table);
    
    KlientoApskaita ka = new KlientoApskaita();

    // sukuriame vidines klases, kai veiksmų yra nemažai ...
    private class VeiksmaiAtidarantFailą implements ActionListener {
			public void actionPerformed( ActionEvent event ) {
				JFileChooser fc = new JFileChooser(".");
                // "." tam, kad rodytų projekto katalogą
				fc.setDialogTitle("Open file for reading");
				fc.setApproveButtonText("Open");
				int rez = fc.showOpenDialog(null);
				if (rez == JFileChooser.APPROVE_OPTION) {
					// veiksmai, kai pasirenkamas atsakymas “Open"
					removePicture();

					File f1 = fc.getSelectedFile();
                                        apskaita.ka.visiKlientai.load(f1.getName());
                                       
                                        loadDataToTable(apskaita.ka.visiKlientai, model);
                                        //table.setVisible(true);
                                        
					paPiešinukas.setVisible(false);
                                        meniuBaras.getComponent(1).setEnabled(true);
                                        
                                        
				} else if (rez == JFileChooser.CANCEL_OPTION) {
                        // rodyti pagrindinio lango centre
                    JOptionPane.showMessageDialog( kviečiantisObjektas,
                        "Reading cancelled",
                        "Read-write", JOptionPane.INFORMATION_MESSAGE);
				}
                          
			}
		}
    
        private class VeiksmaiGreitojiPagalba implements ActionListener {
			public void actionPerformed( ActionEvent event ) {
                // Galimos alternatyvos
//				String programa = System.getenv("windir") + File.separatorChar +
//                                "system32" + File.separatorChar + "calc.exe";
				String programa = "C:\\WINDOWS\\system32\\calc.exe";
				try {
					Process p = Runtime.getRuntime().exec(programa);
				} catch (IOException ex) {
					JOptionPane.showMessageDialog( kviečiantisObjektas,
                            "Executable <" + programa + "> not found",
                            "Klaida", JOptionPane.ERROR_MESSAGE );
				}
			}
		}
        private class VeiksmaiDokumentacija implements ActionListener {
			public void actionPerformed( ActionEvent event ) {
				File f = null;
				try {
					f = new File("dist\\javadoc\\index.html").getAbsoluteFile();
					Desktop.getDesktop().open(f);
					JOptionPane.showMessageDialog( kviečiantisObjektas,
                            "Documentation opened in browser successfully",
                            "Information", JOptionPane.INFORMATION_MESSAGE );
				} catch (IllegalArgumentException ex) {
					JOptionPane.showMessageDialog( kviečiantisObjektas,
                            "Documentation file <" + f.toString() +
                            "> not found or documentation is not generated yet\n"
						, "Error", JOptionPane.ERROR_MESSAGE );
				} catch (IOException ex) {
					JOptionPane.showMessageDialog( kviečiantisObjektas,
                        "Opening documentation file <" + f.toString() +
                        "> failed", "Error", JOptionPane.ERROR_MESSAGE );
				}
			}
		}
        
    private class age implements ActionListener{

        public void actionPerformed(ActionEvent e) {
            
            int min = Integer.parseInt(JOptionPane.showInputDialog("Enter min age"));
            int max = Integer.parseInt(JOptionPane.showInputDialog("Enter max age"));
            removePicture();
            apskaita.age(min, max);
            loadDataToTable(apskaita.klientai, model);
        }
        
    }
    
    
    private class maxClient implements ActionListener{

        public void actionPerformed(ActionEvent e) {
            removePicture();
           apskaita.maxClient();
           loadDataToTable(apskaita.klientai, model);
        }
        
    }
    
    private class model implements ActionListener{

        public void actionPerformed(ActionEvent e) {
            String carmodel = JOptionPane.showInputDialog("Enter model");
            removePicture();
            apskaita.model(carmodel);
            loadDataToTable(apskaita.klientai, model);
        }
        
    }
    
    private class newClients implements ActionListener{

        public void actionPerformed(ActionEvent e) {
            int year = Integer.parseInt(JOptionPane.showInputDialog("Enter year"));
            removePicture();
            apskaita.newClients(year);
            loadDataToTable(apskaita.klientai, model);
        }
        
    }
    
    private class price implements ActionListener{

        public void actionPerformed(ActionEvent e) {
            int min = Integer.parseInt(JOptionPane.showInputDialog("Enter minimum price"));
            int max = Integer.parseInt(JOptionPane.showInputDialog("Enter maximum price"));
            removePicture();
            apskaita.price(min, max);
            loadDataToTable(apskaita.klientai, model);
        }
        
    }
    public SasajaSuMeniu() {
        meniuIdiegimas();
    }
    
    private void removePicture(){
        rodytiPiešinuką = false;
				if (!pa1.isShowing()) {
					vidus = getContentPane();
					vidus.setLayout(new BorderLayout());
					vidus.add(pa1);
				}
				paPiešinukas.setVisible(false);
                                Font font = new Font("Consolas", Font.BOLD, 14);
    }
    
    private void loadDataToTable(ListKTUx<Klientas> visiKlientai, DefaultTableModel model){
        for (int i = model.getRowCount() - 1; i >= 0 ;i--){
            model.removeRow(i);
        }
        for (Klientas k : visiKlientai){
            Object [] dataRow = {k.getPavadinimas(), k.getKodas(), k.getAmzius(),
                k.getAutomobilis().getMarkė(), k.getAutomobilis().getModelis(),
                k.getAutomobilis().getRida(), k.getAutomobilis().getGamMetai(),
                k.getAutomobilis().getKaina()};
            model.addRow(dataRow);
        }
    }

    private void meniuIdiegimas() {
        setJMenuBar(meniuBaras);
		JMenu mFailai = new JMenu( "File" );
		meniuBaras.add(mFailai);
		JMenu mAuto	= new JMenu( "Client accounting" );
                mAuto.setEnabled(false);
		mAuto.setMnemonic( 'a' ); // Alt + a
		meniuBaras.add(mAuto);
		JMenu mPagalba = new JMenu( "Help" );
		meniuBaras.add(mPagalba);
		//    Grupė  "Failai" :
		JMenuItem miSkaityti = new JMenuItem( "Read from file..." );
                miSkaityti.setEnabled(true);
		mFailai.add(miSkaityti);
		miSkaityti.addActionListener(new VeiksmaiAtidarantFailą());
		JMenuItem miBaigti = new JMenuItem( "Exit" );
		miBaigti.setMnemonic( 'b' ); // Alt + b
		mFailai.add(miBaigti);
        // kadangi išėjimo iš programos metodas trumpas, rašome vietoje
		miBaigti.addActionListener(new ActionListener() {
			public void actionPerformed( ActionEvent event ) {
				System.exit(0);
			}
		} );

		//	Grupė "Automobiliu apskaita"
		JMenuItem miKaina = new JMenuItem("Select clients by price");
		mAuto.add(miKaina);
		miKaina.addActionListener(new price());
                
                JMenuItem age = new JMenuItem("Select clients by age");
                mAuto.add(age);
                age.addActionListener(new age());
                
                JMenuItem maxclient = new JMenuItem("Most expensive client");
                mAuto.add(maxclient);
                maxclient.addActionListener(new maxClient());
                
                JMenuItem model = new JMenuItem("Select client by model");
                mAuto.add(model);
                model.addActionListener(new model());
                
                JMenuItem newclient = new JMenuItem("New client");
                mAuto.add(newclient);
                newclient.addActionListener(new newClients());


        //    Grupė  "Pagalba" :
		JMenuItem miDokumentacija = new JMenuItem( "Package documentation" );
		mPagalba.add(miDokumentacija);
		miDokumentacija.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1,
                ActionEvent.ALT_MASK));
		miDokumentacija.addActionListener(new VeiksmaiDokumentacija() );
		JMenuItem miGreitojiPagalba = new JMenuItem( "Emergency :-)" );
		mPagalba.add(miGreitojiPagalba);
		miGreitojiPagalba.addActionListener(new VeiksmaiGreitojiPagalba() );

		JMenuItem miApie = new JMenuItem( "About..." );
		mPagalba.add(miApie);
		miApie.addActionListener(new ActionListener() {
			public void actionPerformed( ActionEvent event ) {
				JOptionPane.showMessageDialog( kviečiantisObjektas,
				  "Client accounting program by Karolis Ryselis\n2012\nv0.1\n\n"+
                                        "Load the file, then use Client accounting menu to perform actions",
                  "About", JOptionPane.INFORMATION_MESSAGE );
			}
		} );

		// Sukuriamas JPanel elementas informacijai išvesti ir padedamas į JFrame langa
		// Pradžioje JPanel elementas nerodomas, o rodomas tik piesinukas.
		pa1.setLayout( new BorderLayout());
		pa1.add(laAntraste, BorderLayout.NORTH);
		pa1.add(zona, BorderLayout.CENTER);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // kad veiktu lango uzdarymas ("kryžiukas")

		// A: Foninė lango spalva
		vidus = getContentPane();
        vidus.setBackground(Color.LIGHT_GRAY);

		// B: Foninis piešinukas, dedamas i lango centrą.
		vidus.setLayout(null);  // piešinukui nustatomas rankinis išdestymas - dydis ir vieta bus nustatoma metodu setLocation
		String failas = "piesinukai" + File.separatorChar + "travelbug.gif"; // failas ten kur class failai
		laPiešinys.setIcon( new ImageIcon( getClass().getResource(failas ))) ;
		paPiešinukas.setBackground(Color.LIGHT_GRAY);
		paPiešinukas.add(laPiešinys);
		paPiešinukas.setBorder(new LineBorder(Color.GRAY));
		add(paPiešinukas);
		žymėsDydis = paPiešinukas.getPreferredSize();
		paPiešinukas.setSize(žymėsDydis); // kitaip getSize piešime duos 0,0
		validate(); // validate paparastai kviečiamas po konteinerio turinio pakeitimo (kontrolei ir "perpiešimui")
		this.addComponentListener(new JFrameLangoVieta()); // Kad "travelbug" išliktų centre keiciant lango matmenis.

    }

	// Ivykio realizaciaja su ComponentAdapter klase tam, kad neįdieginėt nereikalingų likusių trijų ComponentListener metodų
	private class JFrameLangoVieta extends ComponentAdapter {
		@Override
		public void componentResized(ComponentEvent e) {
			if (rodytiPiešinuką) {
				Dimension d = getSize();
				paPiešinukas.setLocation(d.width/2 - žymėsDydis.width/2,
								d.height/2 - žymėsDydis.height/2 - meniuBaras.getPreferredSize().height);
				validate();
				// P.S. Jei tiksliau centruoti, reiketų dar įvertinti ir JFrame lango titulinę eilutį
			} else
                paPiešinukas.setVisible(false);

		}
	}

    public static void main(String[] args) {
        SasajaSuMeniu langas = new SasajaSuMeniu();
        langas.setSize(1000, 400);
        langas.setLocation(200, 200);
        langas.setTitle("Client accounting");
        langas.setVisible(true);
    }

}
