package dialogai;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;

public class Factorial extends JFrame implements ActionListener {

    JTextField duom = new JTextField("1", 10);
    JTextField rez = new JTextField("1", 10);
    JButton jbSkaičiuoti = new JButton("Calculate");
    JPanel datapanel = new JPanel();
    JPanel resultpanel = new JPanel();
    JPanel buttonpanel = new JPanel();
    JPanel main = new JPanel();

    public Factorial() {
        Container vidus = getContentPane();
        vidus.add(main);
        jbSkaičiuoti.addActionListener(this);
//        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        išdėstymas();
        kosmetika();
        setVisible(true);
        pack();
    }
    static private int pradX=100;
    static private int pradY=50;
    public void išdėstymas() {
        setLocation(pradX+=30, pradY+=30);
        main.add(datapanel);
        main.add(resultpanel);
        main.add(buttonpanel);

        GridBagLayout dėstymoBūdas = new GridBagLayout();
        GridBagConstraints dėsnis = new GridBagConstraints();
        datapanel.setLayout(dėstymoBūdas);
        resultpanel.setLayout(dėstymoBūdas);

        dėsnis.fill = GridBagConstraints.NONE;
        dėsnis.insets = new Insets(5, 8, 0, 6);

        dėsnis.anchor = GridBagConstraints.LINE_END;
        dėsnis.gridy = GridBagConstraints.RELATIVE;
        dėsnis.gridx = 0;
        datapanel.add(new JLabel("Number"), dėsnis);
        
        resultpanel.add(new JLabel("Factorial"), dėsnis);

        dėsnis.anchor = GridBagConstraints.LINE_START;
        dėsnis.gridx = 1;

        datapanel.add(duom, dėsnis);
        resultpanel.add(rez, dėsnis);


        buttonpanel.add(jbSkaičiuoti);
    }

    public void kosmetika() {
        setTitle("Aritmetics demo");
        datapanel.setBorder(new TitledBorder("Your number"));
        main.setBackground(Color.BLUE);
        datapanel.setBackground(Color.CYAN);
        resultpanel.setBackground(Color.DARK_GRAY);
        buttonpanel.setBackground(Color.GRAY);
    }

    public void actionPerformed(ActionEvent event) {
        try {
            double a = Integer.parseInt(duom.getText());
            int result = 1;
            for (int i = 1; i <= a; i++){
                result = result * i;
                if (result < 0){
                    break;
                }
            }
            
            if (result > 0){
                rez.setText(Integer.toString(result));
            }
            else{
                rez.setText("Number too large");
            }
            if (a < 0){
                rez.setText("Number negative");
            }
        } catch (NumberFormatException exc) {
            JOptionPane.showMessageDialog (this,"Wrong format");
        }
    }
}
