package dialogai;


import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;
import javax.swing.border.TitledBorder;

public class MultiplicationGame extends JFrame implements ActionListener {

    JTextField a=   new JTextField("1", 14);
    JTextField b=  new JTextField("1", 14);
    JTextField result= new JTextField("", 14);
    JTextField iscorrect=  new JTextField("", 14);
    JTextField accuracy= new JTextField("", 14);

    JButton enter=         new JButton("Submit");
    JPanel vars=    new JPanel();
    JPanel results =    new JPanel();
    JPanel stats =  new JPanel();
    JPanel main =        new JPanel();
    JPanel button = new JPanel();
    JPanel historypanel = new JPanel();
    

    JTextArea history= new JTextArea(12,24);
    JScrollPane scrhistory=new JScrollPane(history);

    Random random = new Random();
    
    private int correct = 0;
    private int total = 0;
    
    public MultiplicationGame() {
        Container inside = getContentPane();
        inside.setLayout(new BoxLayout(inside, BoxLayout.Y_AXIS));
        inside.add(main);
        inside.add(historypanel);
        enter.addActionListener(this);
//        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        išdėstymas();
        kosmetika();
        setVisible(true);
        pack();
    }
    public void išdėstymas() {
        
        setLocation(500, 20);
        // sudedame duomenis į paneles
        historypanel.add(scrhistory);
        main.add(vars);
        main.add(results);
        main.add(stats);

        GridBagLayout dėstymoBūdas = new GridBagLayout();
        GridBagConstraints dėsnis = new GridBagConstraints();
        vars.setLayout(dėstymoBūdas);
        results.setLayout(dėstymoBūdas);
        stats.setLayout(dėstymoBūdas);

        dėsnis.fill = GridBagConstraints.NONE;
        dėsnis.insets = new Insets(5, 8, 0, 6);

        dėsnis.anchor = GridBagConstraints.LINE_END;
        dėsnis.gridy = GridBagConstraints.RELATIVE;
        dėsnis.gridx = 0;
        vars.add(new JLabel("a="), dėsnis);
        vars.add(new JLabel("b="), dėsnis);
        results.add(new JLabel("a*b="), dėsnis);
        
        stats.add(new JLabel("Correct?"), dėsnis);
        stats.add(new JLabel("Accuracy"), dėsnis);

        dėsnis.anchor = GridBagConstraints.LINE_START;
        dėsnis.gridx = 1;

        vars.add(a,dėsnis);
        vars.add(b,dėsnis);
        results.add(result,dėsnis);
        results.add(enter, dėsnis);
        stats.add(iscorrect,dėsnis);
        stats.add(accuracy,dėsnis);
    }

    public void kosmetika() {
        setTitle("Can you multiply and stuff?");
        vars.setBorder(new TitledBorder("Multiply stuff"));
        vars.setBackground(Color.GREEN);
        results.setBorder(new TitledBorder("What you get"));
        results.setBackground(Color.LIGHT_GRAY);
        stats.setBackground(Color.MAGENTA);
        main. setBackground(Color.ORANGE);
        button.setBackground(Color.RED);
    }
    public void actionPerformed(ActionEvent e) {
        try {
            int one = Integer.parseInt(a.getText());
            int two = Integer.parseInt(b.getText());
            int product = one*two;
            int answer = Integer.parseInt(result.getText());
            if  (answer == product){
                correct++;
                iscorrect.setBackground(Color.GREEN);
            }
            else{
                iscorrect.setBackground(Color.RED);
            }
            total++;
            a.setText(Integer.toString(random.nextInt(1000)+1));
            b.setText(Integer.toString(random.nextInt(1000)+1));
            result.setText("");
            accuracy.setText(Integer.toString((100*correct/total)) + "%");
            history.append(String.format("%3d: %4d * %4d = %4d (%d)\n", total,
                    one, two, product, answer));
            
        } catch (NumberFormatException exc) {
            JOptionPane.showMessageDialog (this,"Bad format");
        }
    }
}
