package dialogai;


/**
 *
 * @author KTU
 */
import Lab3individualus.Klientas;
import Lab3individualus.KlientoApskaita;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import studijosKTU.ListKTUx;

public class ClientAccounting {
	public ListKTUx<Klientas> klientai;
        public KlientoApskaita ka = new KlientoApskaita();

	/**
	 * Tai tik metodo imitacija - panaudokite L2/L3 darbų atrinkimo metodus
	 *
	 * @param taLaukas JTextArea klasės objektas
	 */
	

	/**
	 * Išvedimas į JTextArea lauką
	 * 
	 * @param taLaukas JTextArea klasės objektas
	 */
	
        
        public void newClients(int year){
            klientai = ka.atrinktiNaujusKlientas(year);
        }
        
       public void model(String model){
           klientai = ka.atrinktiMarkęModelį(model);
       }
       
       public void age(int min, int max){
           klientai = ka.atrinktiPagalAmziu(min, max);
       }
       
       public void price(int min, int max){
          
           klientai = ka.atrinktiPagalKainą(min, max);
       }
       
       public void maxClient(){
           klientai = ka.maksimaliosKainosKlientas();
       }

	/**
	 * Tai jau turėtų būti naujas sistemines klases Ks metodas
	 *	(arba naujos studijosKTU paketo klasės KsSwing metodas)
	 * @param obj išvedamas objektas
	 * @param ta JTextArea klasės objektas
	 */
    /*static public void ouSwn(Object obj, JTable ta) {
            
		ta.append(obj.toString() + "\n");
    }*/
	//-----------------------------------------------------------------------------------

	/**
	 * Failo skaitymas ir jo turinio išvedimas į JTextArea
	 * @param fName File klasės objektas
	 * @param ta JTextArea klasės objektas
	 */
    /*public void loadAndPrint(File fName, JTextArea ta) {
        try {
            BufferedReader fReader =  new BufferedReader(new FileReader(fName));
            String line;
			ta.append("\n     Duomenys is failo <" + fName.getName() + ">\n");

            while ((line = fReader.readLine()) != null) {
				ta.append(line + "\n");
            }
            fReader.close();
        } catch (IOException e) {
            ta.append("\n!!! Failo " + fName.getName() + " skaitymo klaida");
        }
	}*/
}
